import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCopyToClipboard } from "@/hooks/use-copy-to-clipboard";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

type GstMode = "add" | "remove";

export default function GstCalculator() {
  const [mode, setMode] = useState<GstMode>("add");
  const [amount, setAmount] = useState<string>("");
  const [gstRate, setGstRate] = useState<string>("18");
  const [gstAmount, setGstAmount] = useState<string>("0.00");
  const [totalAmount, setTotalAmount] = useState<string>("0.00");
  const [customRate, setCustomRate] = useState<boolean>(false);
  const [customRateValue, setCustomRateValue] = useState<string>("");
  const { copyToClipboard } = useCopyToClipboard();

  // Calculate GST whenever inputs change
  useEffect(() => {
    calculateGst();
  }, [mode, amount, gstRate, customRate, customRateValue]);

  const calculateGst = () => {
    const originalAmount = parseFloat(amount);
    const rate = customRate ? parseFloat(customRateValue) : parseFloat(gstRate);
    
    if (isNaN(originalAmount) || isNaN(rate)) {
      setGstAmount("0.00");
      setTotalAmount("0.00");
      return;
    }

    if (mode === "add") {
      // Add GST to original amount
      const gst = (originalAmount * rate) / 100;
      const total = originalAmount + gst;
      
      setGstAmount(gst.toFixed(2));
      setTotalAmount(total.toFixed(2));
    } else {
      // Remove GST from amount
      const gst = originalAmount * (rate / (100 + rate));
      const basePrice = originalAmount - gst;
      
      setGstAmount(gst.toFixed(2));
      setTotalAmount(basePrice.toFixed(2));
    }
  };

  const handleReset = () => {
    setAmount("");
    setGstRate("18");
    setGstAmount("0.00");
    setTotalAmount("0.00");
    setCustomRate(false);
    setCustomRateValue("");
  };

  const handleCopyResult = () => {
    const textToCopy = mode === "add" 
      ? `Amount: ₹${amount}\nGST (${customRate ? customRateValue : gstRate}%): ₹${gstAmount}\nTotal with GST: ₹${totalAmount}`
      : `Amount with GST: ₹${amount}\nGST (${customRate ? customRateValue : gstRate}%): ₹${gstAmount}\nOriginal Price: ₹${totalAmount}`;
    
    copyToClipboard(textToCopy);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8 flex-grow">
        {/* Page Title */}
        <section className="mb-8 max-w-3xl mx-auto">
          <div className="p-5 bg-white rounded-lg shadow-sm mb-6">
            <h2 className="text-lg md:text-xl font-semibold mb-2">GST Calculator – Add or Remove GST Easily</h2>
            <p className="text-gray-600">Calculate GST instantly with our easy-to-use GST calculator. Add or remove GST from a price with real-time results.</p>
          </div>
        </section>
        
        {/* GST Calculator */}
        <div className="max-w-3xl mx-auto">
          <Card className="bg-white rounded-lg shadow-sm p-6 mb-8">
            <CardContent className="p-0">
              <h3 className="text-lg font-semibold mb-4">GST Calculator</h3>
              
              {/* Mode Selection */}
              <div className="mb-6">
                <Label className="block text-sm font-medium text-gray-700 mb-2">Select Mode</Label>
                <RadioGroup 
                  value={mode} 
                  onValueChange={(value) => setMode(value as GstMode)}
                  className="flex flex-wrap gap-4"
                >
                  <div className={`flex items-center space-x-2 p-3 rounded-md border ${mode === 'add' ? 'bg-blue-50 border-blue-200' : 'border-gray-200'}`}>
                    <RadioGroupItem value="add" id="add-gst" />
                    <Label htmlFor="add-gst" className="font-medium cursor-pointer">
                      Add GST
                      <span className="block text-xs text-gray-500 mt-1">Calculate GST on your original price</span>
                    </Label>
                  </div>
                  <div className={`flex items-center space-x-2 p-3 rounded-md border ${mode === 'remove' ? 'bg-blue-50 border-blue-200' : 'border-gray-200'}`}>
                    <RadioGroupItem value="remove" id="remove-gst" />
                    <Label htmlFor="remove-gst" className="font-medium cursor-pointer">
                      Remove GST
                      <span className="block text-xs text-gray-500 mt-1">Find original price from a GST-inclusive amount</span>
                    </Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="space-y-6">
                {/* Amount Input */}
                <div className="form-group">
                  <Label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">
                    {mode === "add" ? "Original Amount" : "Amount (GST Inclusive)"}
                  </Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <span className="text-gray-500">₹</span>
                    </div>
                    <Input
                      type="number"
                      id="amount"
                      placeholder="Enter amount"
                      className="pl-8 py-3 bg-white"
                      step="0.01"
                      min="0"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                    />
                  </div>
                </div>
                
                {/* GST Rate */}
                <div className="form-group">
                  <Label className="block text-sm font-medium text-gray-700 mb-2">GST Rate</Label>
                  <div className="flex flex-col space-y-4 md:flex-row md:space-y-0 md:space-x-4">
                    {!customRate ? (
                      <div className="flex-1">
                        <Select value={gstRate} onValueChange={setGstRate}>
                          <SelectTrigger className="w-full py-5">
                            <SelectValue placeholder="Select GST Rate" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="5">5%</SelectItem>
                            <SelectItem value="12">12%</SelectItem>
                            <SelectItem value="18">18%</SelectItem>
                            <SelectItem value="28">28%</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    ) : (
                      <div className="flex-1 relative">
                        <Input
                          type="number"
                          placeholder="Custom rate"
                          className="pr-8 py-3 bg-white"
                          step="0.01"
                          min="0"
                          max="100"
                          value={customRateValue}
                          onChange={(e) => setCustomRateValue(e.target.value)}
                        />
                        <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                          <span className="text-gray-500">%</span>
                        </div>
                      </div>
                    )}
                    <Button 
                      variant="outline" 
                      className="py-5 px-5"
                      onClick={() => {
                        setCustomRate(!customRate);
                        if (customRate) {
                          setCustomRateValue("");
                        }
                      }}
                    >
                      {customRate ? "Use Standard Rates" : "Use Custom Rate"}
                    </Button>
                  </div>
                </div>
                
                {/* Results */}
                <div className="bg-gray-50 p-4 rounded-lg mt-6">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-700">Calculation Results</h4>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-blue-600 hover:text-blue-800"
                      onClick={handleCopyResult}
                    >
                      <span className="material-icons-round mr-1">content_copy</span>
                      Copy
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <div className="bg-white p-3 rounded-md border border-gray-200">
                      <div className="text-sm text-gray-500 mb-1">
                        {mode === "add" ? "GST Amount" : "GST Component"}
                      </div>
                      <div className="text-xl font-bold text-primary-600">₹{gstAmount}</div>
                      <div className="text-xs text-gray-500 mt-1">
                        {customRate ? customRateValue : gstRate}% GST
                      </div>
                    </div>
                    
                    <div className="bg-white p-3 rounded-md border border-gray-200">
                      <div className="text-sm text-gray-500 mb-1">
                        {mode === "add" ? "Total Amount with GST" : "Price without GST"}
                      </div>
                      <div className="text-xl font-bold text-primary-600">₹{totalAmount}</div>
                    </div>
                  </div>
                </div>
                
                {/* Reset Button */}
                <div className="flex justify-end">
                  <Button 
                    variant="outline" 
                    onClick={handleReset}
                    className="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200"
                  >
                    Reset
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Information Section */}
          <Card className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <CardContent className="p-0">
              <h3 className="text-lg font-semibold mb-4">About GST Calculation</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-2">Adding GST</h4>
                  <p className="text-gray-600 mb-3">To calculate GST amount and add it to your original price:</p>
                  <div className="bg-gray-50 p-3 rounded-md mb-2">
                    <p className="font-mono">GST Amount = (Original Amount × GST Rate) / 100</p>
                    <p className="font-mono mt-1">Total Amount = Original Amount + GST Amount</p>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Removing GST</h4>
                  <p className="text-gray-600 mb-3">To calculate GST component and find the original price from a GST-inclusive amount:</p>
                  <div className="bg-gray-50 p-3 rounded-md mb-2">
                    <p className="font-mono">GST Amount = Amount × (GST Rate / (100 + GST Rate))</p>
                    <p className="font-mono mt-1">Original Price = Amount - GST Amount</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}