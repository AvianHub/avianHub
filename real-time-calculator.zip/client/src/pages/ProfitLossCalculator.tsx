import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useCopyToClipboard } from "@/hooks/use-copy-to-clipboard";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

type ResultType = "profit" | "loss" | "neutral";

export default function ProfitLossCalculator() {
  const [costPrice, setCostPrice] = useState<string>("");
  const [sellingPrice, setSellingPrice] = useState<string>("");
  const [quantity, setQuantity] = useState<string>("1");
  const [result, setResult] = useState<ResultType | null>(null);
  const [amount, setAmount] = useState<string>("0.00");
  const [percentage, setPercentage] = useState<string>("0.00");
  const [message, setMessage] = useState<string>("");
  const { copyToClipboard } = useCopyToClipboard();

  // Calculate profit/loss whenever inputs change
  useEffect(() => {
    calculateProfitLoss();
  }, [costPrice, sellingPrice, quantity]);

  const calculateProfitLoss = () => {
    const cp = parseFloat(costPrice);
    const sp = parseFloat(sellingPrice);
    const qty = parseFloat(quantity || "1");

    if (isNaN(cp) || isNaN(sp) || isNaN(qty) || cp <= 0 || sp <= 0 || qty <= 0) {
      setResult(null);
      setAmount("0.00");
      setPercentage("0.00");
      setMessage("");
      return;
    }

    // Calculate total values
    const totalCP = cp * qty;
    const totalSP = sp * qty;
    
    if (totalSP > totalCP) {
      // Profit
      const profitAmount = totalSP - totalCP;
      const profitPercentage = (profitAmount / totalCP) * 100;
      
      setResult("profit");
      setAmount(profitAmount.toFixed(2));
      setPercentage(profitPercentage.toFixed(2));
      setMessage(`You made a profit of ₹${profitAmount.toFixed(2)} (${profitPercentage.toFixed(2)}%)`);
    } else if (totalCP > totalSP) {
      // Loss
      const lossAmount = totalCP - totalSP;
      const lossPercentage = (lossAmount / totalCP) * 100;
      
      setResult("loss");
      setAmount(lossAmount.toFixed(2));
      setPercentage(lossPercentage.toFixed(2));
      setMessage(`You incurred a loss of ₹${lossAmount.toFixed(2)} (${lossPercentage.toFixed(2)}%)`);
    } else {
      // No profit, no loss
      setResult("neutral");
      setAmount("0.00");
      setPercentage("0.00");
      setMessage("No profit, no loss");
    }
  };

  const handleReset = () => {
    setCostPrice("");
    setSellingPrice("");
    setQuantity("1");
    setResult(null);
    setAmount("0.00");
    setPercentage("0.00");
    setMessage("");
  };

  const handleCopyResult = () => {
    if (result) {
      copyToClipboard(`Cost Price: ₹${costPrice}${
        parseFloat(quantity) > 1 ? ` × ${quantity} = ₹${(parseFloat(costPrice) * parseFloat(quantity)).toFixed(2)}` : ""
      }\nSelling Price: ₹${sellingPrice}${
        parseFloat(quantity) > 1 ? ` × ${quantity} = ₹${(parseFloat(sellingPrice) * parseFloat(quantity)).toFixed(2)}` : ""
      }\n${message}`);
    }
  };

  const getResultColor = () => {
    switch (result) {
      case "profit":
        return "text-green-600";
      case "loss":
        return "text-red-600";
      case "neutral":
        return "text-gray-600";
      default:
        return "text-gray-400";
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8 flex-grow">
        {/* Page Title */}
        <section className="mb-8 max-w-3xl mx-auto">
          <div className="p-5 bg-white rounded-lg shadow-sm mb-6">
            <h2 className="text-lg md:text-xl font-semibold mb-2">Profit and Loss Calculator</h2>
            <p className="text-gray-600">Use this real-time profit and loss calculator to instantly find profit, loss, and percentage values based on cost and selling price.</p>
          </div>
        </section>
        
        {/* Profit & Loss Calculator */}
        <div className="max-w-3xl mx-auto">
          <Card className="bg-white rounded-lg shadow-sm p-6 mb-8">
            <CardContent className="p-0">
              <h3 className="text-lg font-semibold mb-6">Calculate Profit & Loss</h3>
              
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Cost Price Input */}
                  <div className="form-group">
                    <Label htmlFor="costPrice" className="block text-sm font-medium text-gray-700 mb-1">
                      Cost Price (CP)*
                    </Label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <span className="text-gray-500">₹</span>
                      </div>
                      <Input
                        type="number"
                        id="costPrice"
                        placeholder="Enter cost price"
                        className="pl-8 py-3 bg-white"
                        step="0.01"
                        min="0.01"
                        value={costPrice}
                        onChange={(e) => setCostPrice(e.target.value)}
                        required
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">The price at which you purchased</p>
                  </div>
                  
                  {/* Selling Price Input */}
                  <div className="form-group">
                    <Label htmlFor="sellingPrice" className="block text-sm font-medium text-gray-700 mb-1">
                      Selling Price (SP)*
                    </Label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <span className="text-gray-500">₹</span>
                      </div>
                      <Input
                        type="number"
                        id="sellingPrice"
                        placeholder="Enter selling price"
                        className="pl-8 py-3 bg-white"
                        step="0.01"
                        min="0.01"
                        value={sellingPrice}
                        onChange={(e) => setSellingPrice(e.target.value)}
                        required
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">The price at which you sold</p>
                  </div>
                </div>
                
                {/* Quantity Input */}
                <div className="form-group max-w-xs">
                  <Label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-1">
                    Quantity (Optional)
                  </Label>
                  <Input
                    type="number"
                    id="quantity"
                    placeholder="Enter quantity"
                    className="py-3 bg-white"
                    min="1"
                    step="1"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                  />
                  <p className="text-xs text-gray-500 mt-1">Default is 1 if left empty</p>
                </div>
                
                {/* Results */}
                <div className={`bg-gray-50 p-4 rounded-lg mt-6 ${result ? 'border-l-4 ' + (
                  result === 'profit' ? 'border-green-500' : 
                  result === 'loss' ? 'border-red-500' : 'border-gray-400'
                ) : ''}`}>
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-medium text-gray-700">Calculation Results</h4>
                    {result && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-blue-600 hover:text-blue-800"
                        onClick={handleCopyResult}
                      >
                        <span className="material-icons-round mr-1">content_copy</span>
                        Copy
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                    <div className="bg-white p-3 rounded-md border border-gray-200">
                      <div className="text-sm text-gray-500 mb-1">Amount</div>
                      <div className={`text-xl font-bold ${getResultColor()}`}>
                        ₹{amount}
                      </div>
                    </div>
                    
                    <div className="bg-white p-3 rounded-md border border-gray-200">
                      <div className="text-sm text-gray-500 mb-1">Percentage</div>
                      <div className={`text-xl font-bold ${getResultColor()}`}>
                        {percentage}%
                      </div>
                    </div>
                  </div>
                  
                  {message && (
                    <div className={`mt-4 p-3 rounded-md ${
                      result === 'profit' ? 'bg-green-50' : 
                      result === 'loss' ? 'bg-red-50' : 'bg-gray-100'
                    }`}>
                      <p className={`font-medium ${getResultColor()}`}>{message}</p>
                    </div>
                  )}
                </div>
                
                {/* Reset Button */}
                <div className="flex justify-end">
                  <Button 
                    variant="outline" 
                    onClick={handleReset}
                    className="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200"
                  >
                    Reset
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Information Section */}
          <Card className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <CardContent className="p-0">
              <h3 className="text-lg font-semibold mb-4">Understanding Profit & Loss Calculation</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-2">Profit Calculation</h4>
                  <p className="text-gray-600 mb-3">When selling price is greater than cost price:</p>
                  <div className="bg-gray-50 p-3 rounded-md mb-2">
                    <p className="font-mono">Profit = Selling Price - Cost Price</p>
                    <p className="font-mono mt-1">Profit % = (Profit / Cost Price) × 100</p>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Loss Calculation</h4>
                  <p className="text-gray-600 mb-3">When cost price is greater than selling price:</p>
                  <div className="bg-gray-50 p-3 rounded-md mb-2">
                    <p className="font-mono">Loss = Cost Price - Selling Price</p>
                    <p className="font-mono mt-1">Loss % = (Loss / Cost Price) × 100</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-5">
                <h4 className="font-medium mb-2">Using Quantity</h4>
                <p className="text-gray-600 mb-3">When dealing with multiple items:</p>
                <div className="bg-gray-50 p-3 rounded-md mb-2">
                  <p className="font-mono">Total Cost Price = Cost Price × Quantity</p>
                  <p className="font-mono mt-1">Total Selling Price = Selling Price × Quantity</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}