import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CalculatorTabs from "@/components/Calculator/CalculatorTabs";
import StandardCalculator from "@/components/Calculator/StandardCalculator";
import ReverseCalculator from "@/components/Calculator/ReverseCalculator";
import AdvancedCalculator from "@/components/Calculator/AdvancedCalculator";
import HowItWorks from "@/components/Calculator/HowItWorks";

type CalculatorTab = "standard" | "reverse" | "advanced";

export default function Home() {
  const [activeTab, setActiveTab] = useState<CalculatorTab>("standard");

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8 flex-grow">
        {/* Introduction Section */}
        <section className="mb-8 max-w-3xl mx-auto">
          <div className="p-5 bg-white rounded-lg shadow-sm mb-6">
            <h2 className="text-lg md:text-xl font-semibold mb-2">Calculate Percentages Instantly</h2>
            <p className="text-gray-600">This calculator offers multiple ways to work with percentages. Select a calculation mode below and get real-time results as you type.</p>
          </div>
        </section>
        
        {/* Calculator Selection */}
        <div className="max-w-4xl mx-auto mb-8">
          <CalculatorTabs activeTab={activeTab} onTabChange={setActiveTab} />
        </div>
        
        {/* Calculator Windows */}
        <div className="grid grid-cols-1 gap-8 max-w-4xl mx-auto">
          {activeTab === "standard" && (
            <div className="calculator-window">
              <StandardCalculator />
            </div>
          )}
          
          {activeTab === "reverse" && (
            <div className="calculator-window">
              <ReverseCalculator />
            </div>
          )}
          
          {activeTab === "advanced" && (
            <div className="calculator-window">
              <AdvancedCalculator />
            </div>
          )}
        </div>
        
        {/* How It Works Section */}
        <HowItWorks />
      </main>
      
      <Footer />
    </div>
  );
}
