import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCopyToClipboard } from "@/hooks/use-copy-to-clipboard";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function AgeCalculator() {
  // Current date for reference and default "to date"
  const today = new Date();
  const [todayString, setTodayString] = useState("");
  
  // Form inputs
  const [birthDay, setBirthDay] = useState<string>("");
  const [birthMonth, setBirthMonth] = useState<string>("");
  const [birthYear, setBirthYear] = useState<string>("");
  
  // Custom "to date" option
  const [useCustomToDate, setUseCustomToDate] = useState(false);
  const [toDay, setToDay] = useState<string>("");
  const [toMonth, setToMonth] = useState<string>("");
  const [toYear, setToYear] = useState<string>("");
  
  // Results
  const [years, setYears] = useState<number | null>(null);
  const [months, setMonths] = useState<number | null>(null);
  const [days, setDays] = useState<number | null>(null);
  const [totalDays, setTotalDays] = useState<number | null>(null);
  const [totalMonths, setTotalMonths] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const { copyToClipboard } = useCopyToClipboard();
  
  // Set today's date string (e.g., "16 May 2025")
  useEffect(() => {
    setTodayString(formatDate(today));
    
    // Set default "to date" as today
    setToDay(today.getDate().toString());
    setToMonth((today.getMonth() + 1).toString()); 
    setToYear(today.getFullYear().toString());
  }, []);
  
  // Calculate age whenever inputs change
  useEffect(() => {
    calculateAge();
  }, [birthDay, birthMonth, birthYear, toDay, toMonth, toYear, useCustomToDate]);
  
  // Format date as "DD Month YYYY"
  const formatDate = (date: Date): string => {
    return date.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };
  
  // Generate arrays for days, months, and years
  const getDaysArray = (month: number, year: number): number[] => {
    // Get the number of days in the selected month
    if (!month || !year) return Array.from({ length: 31 }, (_, i) => i + 1);
    
    const daysInMonth = new Date(year, month, 0).getDate();
    return Array.from({ length: daysInMonth }, (_, i) => i + 1);
  };
  
  const getMonthsArray = (): { value: string; label: string }[] => {
    return [
      { value: "1", label: "January" },
      { value: "2", label: "February" },
      { value: "3", label: "March" },
      { value: "4", label: "April" },
      { value: "5", label: "May" },
      { value: "6", label: "June" },
      { value: "7", label: "July" },
      { value: "8", label: "August" },
      { value: "9", label: "September" },
      { value: "10", label: "October" },
      { value: "11", label: "November" },
      { value: "12", label: "December" }
    ];
  };
  
  const getYearsArray = (): number[] => {
    const currentYear = today.getFullYear();
    return Array.from({ length: currentYear - 1899 }, (_, i) => 1900 + i);
  };
  
  const calculateAge = () => {
    // Clear previous results
    setYears(null);
    setMonths(null);
    setDays(null);
    setTotalDays(null);
    setTotalMonths(null);
    setError(null);
    
    // Validate inputs
    if (!birthDay || !birthMonth || !birthYear) {
      return;
    }
    
    // Parse inputs
    const birthDateObj = new Date(
      parseInt(birthYear),
      parseInt(birthMonth) - 1,
      parseInt(birthDay)
    );
    
    // Validate birth date
    if (isNaN(birthDateObj.getTime())) {
      setError("Please enter a valid date of birth");
      return;
    }
    
    // Determine "to date" (either today or custom date)
    let toDateObj: Date;
    
    if (useCustomToDate) {
      if (!toDay || !toMonth || !toYear) {
        return;
      }
      
      toDateObj = new Date(
        parseInt(toYear),
        parseInt(toMonth) - 1,
        parseInt(toDay)
      );
      
      // Validate "to date"
      if (isNaN(toDateObj.getTime())) {
        setError("Please enter a valid 'to date'");
        return;
      }
    } else {
      toDateObj = new Date(); // Today
    }
    
    // Check if birth date is in the future relative to "to date"
    if (birthDateObj > toDateObj) {
      setError("Date of birth cannot be in the future");
      return;
    }
    
    // Calculate age
    let ageYears = toDateObj.getFullYear() - birthDateObj.getFullYear();
    let ageMonths = toDateObj.getMonth() - birthDateObj.getMonth();
    let ageDays = toDateObj.getDate() - birthDateObj.getDate();
    
    // Adjust for negative days
    if (ageDays < 0) {
      ageMonths--;
      // Add days from previous month
      const prevMonth = new Date(toDateObj.getFullYear(), toDateObj.getMonth(), 0);
      ageDays += prevMonth.getDate();
    }
    
    // Adjust for negative months
    if (ageMonths < 0) {
      ageYears--;
      ageMonths += 12;
    }
    
    // Calculate total days
    const diffTime = Math.abs(toDateObj.getTime() - birthDateObj.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    // Calculate total months (approximate)
    const totalMonthsCalc = ageYears * 12 + ageMonths;
    
    // Set results
    setYears(ageYears);
    setMonths(ageMonths);
    setDays(ageDays);
    setTotalDays(diffDays);
    setTotalMonths(totalMonthsCalc);
  };
  
  const handleReset = () => {
    setBirthDay("");
    setBirthMonth("");
    setBirthYear("");
    setToDay(today.getDate().toString());
    setToMonth((today.getMonth() + 1).toString());
    setToYear(today.getFullYear().toString());
    setUseCustomToDate(false);
    setYears(null);
    setMonths(null);
    setDays(null);
    setTotalDays(null);
    setTotalMonths(null);
    setError(null);
  };
  
  const handleCopyResult = () => {
    if (years !== null && months !== null && days !== null) {
      const birthDateStr = `${birthDay} ${getMonthsArray().find(m => m.value === birthMonth)?.label || birthMonth} ${birthYear}`;
      const toDateStr = useCustomToDate 
        ? `${toDay} ${getMonthsArray().find(m => m.value === toMonth)?.label || toMonth} ${toYear}`
        : todayString;
        
      const resultText = `Age from ${birthDateStr} to ${toDateStr}:\n${years} years, ${months} months, and ${days} days\nTotal: ${totalDays} days (approximately ${totalMonths} months)`;
      
      copyToClipboard(resultText);
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8 flex-grow">
        {/* Page Title */}
        <section className="mb-8 max-w-3xl mx-auto">
          <div className="p-5 bg-white rounded-lg shadow-sm mb-6">
            <h2 className="text-lg md:text-xl font-semibold mb-2">Age Calculator</h2>
            <p className="text-gray-600">Calculate your exact age in years, months, and days. Find out how old you are from your date of birth to today or any specific date.</p>
          </div>
        </section>
        
        {/* Age Calculator */}
        <div className="max-w-3xl mx-auto">
          <Card className="bg-white rounded-lg shadow-sm p-6 mb-8">
            <CardContent className="p-0">
              <h3 className="text-lg font-semibold mb-4">Calculate Your Age</h3>
              
              <div className="text-sm text-gray-500 mb-6">
                Today is: <span className="font-medium">{todayString}</span>
              </div>
              
              <div className="space-y-6">
                {/* Date of Birth Inputs */}
                <div>
                  <Label className="block text-base font-medium text-gray-700 mb-3">
                    Enter your Date of Birth
                  </Label>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="birthDay" className="block text-sm text-gray-600 mb-1">
                        Day
                      </Label>
                      <Select value={birthDay} onValueChange={setBirthDay}>
                        <SelectTrigger id="birthDay" className="w-full">
                          <SelectValue placeholder="Day" />
                        </SelectTrigger>
                        <SelectContent>
                          {getDaysArray(parseInt(birthMonth), parseInt(birthYear)).map(day => (
                            <SelectItem key={`birth-day-${day}`} value={day.toString()}>
                              {day}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="birthMonth" className="block text-sm text-gray-600 mb-1">
                        Month
                      </Label>
                      <Select value={birthMonth} onValueChange={setBirthMonth}>
                        <SelectTrigger id="birthMonth" className="w-full">
                          <SelectValue placeholder="Month" />
                        </SelectTrigger>
                        <SelectContent>
                          {getMonthsArray().map(month => (
                            <SelectItem key={`birth-month-${month.value}`} value={month.value}>
                              {month.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="birthYear" className="block text-sm text-gray-600 mb-1">
                        Year
                      </Label>
                      <Select value={birthYear} onValueChange={setBirthYear}>
                        <SelectTrigger id="birthYear" className="w-full">
                          <SelectValue placeholder="Year" />
                        </SelectTrigger>
                        <SelectContent>
                          {getYearsArray().map(year => (
                            <SelectItem key={`birth-year-${year}`} value={year.toString()}>
                              {year}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
                
                {/* Custom To Date Toggle */}
                <div>
                  <div className="flex items-center mb-3">
                    <input
                      type="checkbox"
                      id="useCustomToDate"
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500 h-4 w-4"
                      checked={useCustomToDate}
                      onChange={(e) => setUseCustomToDate(e.target.checked)}
                    />
                    <Label htmlFor="useCustomToDate" className="ml-2 block text-sm font-medium text-gray-700">
                      Calculate age as of a specific date (instead of today)
                    </Label>
                  </div>
                  
                  {useCustomToDate && (
                    <div>
                      <Label className="block text-base font-medium text-gray-700 mb-3">
                        To Date
                      </Label>
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <Label htmlFor="toDay" className="block text-sm text-gray-600 mb-1">
                            Day
                          </Label>
                          <Select value={toDay} onValueChange={setToDay}>
                            <SelectTrigger id="toDay" className="w-full">
                              <SelectValue placeholder="Day" />
                            </SelectTrigger>
                            <SelectContent>
                              {getDaysArray(parseInt(toMonth), parseInt(toYear)).map(day => (
                                <SelectItem key={`to-day-${day}`} value={day.toString()}>
                                  {day}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="toMonth" className="block text-sm text-gray-600 mb-1">
                            Month
                          </Label>
                          <Select value={toMonth} onValueChange={setToMonth}>
                            <SelectTrigger id="toMonth" className="w-full">
                              <SelectValue placeholder="Month" />
                            </SelectTrigger>
                            <SelectContent>
                              {getMonthsArray().map(month => (
                                <SelectItem key={`to-month-${month.value}`} value={month.value}>
                                  {month.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="toYear" className="block text-sm text-gray-600 mb-1">
                            Year
                          </Label>
                          <Select value={toYear} onValueChange={setToYear}>
                            <SelectTrigger id="toYear" className="w-full">
                              <SelectValue placeholder="Year" />
                            </SelectTrigger>
                            <SelectContent>
                              {getYearsArray().map(year => (
                                <SelectItem key={`to-year-${year}`} value={year.toString()}>
                                  {year}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                
                {/* Results Section */}
                <div className="bg-gray-50 p-5 rounded-lg mt-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-medium text-gray-700">Your Age</h4>
                    {years !== null && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-blue-600 hover:text-blue-800"
                        onClick={handleCopyResult}
                      >
                        <span className="material-icons-round mr-1">content_copy</span>
                        Copy
                      </Button>
                    )}
                  </div>
                  
                  {error ? (
                    <div className="p-3 bg-red-50 text-red-600 rounded-md">
                      {error}
                    </div>
                  ) : (
                    <>
                      {years !== null && months !== null && days !== null ? (
                        <div className="space-y-4">
                          <div className="bg-white p-4 rounded-md border border-gray-200">
                            <p className="text-lg md:text-xl font-bold text-primary-600">
                              {years} years, {months} months, and {days} days old
                            </p>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="bg-white p-3 rounded-md border border-gray-200">
                              <div className="text-sm text-gray-500 mb-1">Total Days</div>
                              <div className="text-lg font-medium">
                                {totalDays?.toLocaleString()} days
                              </div>
                            </div>
                            
                            <div className="bg-white p-3 rounded-md border border-gray-200">
                              <div className="text-sm text-gray-500 mb-1">Total Months (approx.)</div>
                              <div className="text-lg font-medium">
                                {totalMonths?.toLocaleString()} months
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center text-gray-500 p-4">
                          Select your date of birth to see your age
                        </div>
                      )}
                    </>
                  )}
                </div>
                
                {/* Reset Button */}
                <div className="flex justify-end">
                  <Button 
                    variant="outline" 
                    onClick={handleReset}
                    className="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200"
                  >
                    Reset
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Information Section */}
          <Card className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <CardContent className="p-0">
              <h3 className="text-lg font-semibold mb-4">About Age Calculation</h3>
              <div>
                <p className="text-gray-600 mb-4">
                  Age calculation is based on the difference between two dates, typically your birth date and today. The calculator accounts for:
                </p>
                <ul className="list-disc pl-5 space-y-2 text-gray-600">
                  <li>Varying month lengths (28-31 days)</li>
                  <li>Leap years (February 29)</li>
                  <li>Accurate calculation of years, months, and days</li>
                </ul>
                <div className="mt-4 p-3 bg-blue-50 rounded-md">
                  <p className="text-sm text-blue-700">
                    <span className="font-medium">Tip:</span> Use the custom date option to calculate your age as of a past date or to see how old you'll be on a future date.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}