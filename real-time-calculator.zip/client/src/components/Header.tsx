import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";

export default function Header() {
  const [location] = useLocation();

  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center">
        <div>
          <Link href="/">
            <div className="text-xl md:text-2xl font-bold text-primary-600 flex items-center cursor-pointer">
              <span className="material-icons-round mr-2">calculate</span>
              Real-Time Calculator
            </div>
          </Link>
        </div>
        <nav className="mt-3 md:mt-0">
          <ul className="flex flex-wrap justify-center gap-2">
            <li>
              <Link href="/">
                <div className={`flex items-center px-2 py-1 rounded-md cursor-pointer ${location === '/' ? 'text-primary-600 font-medium bg-blue-50' : 'text-gray-600 hover:text-primary-600'}`}>
                  <span className="material-icons-round mr-1 text-sm">percent</span>
                  Percentage
                </div>
              </Link>
            </li>
            <li>
              <Link href="/gst-calculator">
                <div className={`flex items-center px-2 py-1 rounded-md cursor-pointer ${location === '/gst-calculator' ? 'text-primary-600 font-medium bg-blue-50' : 'text-gray-600 hover:text-primary-600'}`}>
                  <span className="material-icons-round mr-1 text-sm">receipt</span>
                  GST
                </div>
              </Link>
            </li>
            <li>
              <Link href="/profit-loss-calculator">
                <div className={`flex items-center px-2 py-1 rounded-md cursor-pointer ${location === '/profit-loss-calculator' ? 'text-primary-600 font-medium bg-blue-50' : 'text-gray-600 hover:text-primary-600'}`}>
                  <span className="material-icons-round mr-1 text-sm">trending_up</span>
                  Profit/Loss
                </div>
              </Link>
            </li>
            <li>
              <Link href="/age-calculator">
                <div className={`flex items-center px-2 py-1 rounded-md cursor-pointer ${location === '/age-calculator' ? 'text-primary-600 font-medium bg-blue-50' : 'text-gray-600 hover:text-primary-600'}`}>
                  <span className="material-icons-round mr-1 text-sm">calendar_today</span>
                  Age
                </div>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
