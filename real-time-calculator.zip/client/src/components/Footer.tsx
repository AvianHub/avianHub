export default function Footer() {
  return (
    <footer className="bg-white mt-12 py-6 border-t border-gray-200">
      <div className="container mx-auto px-4">
        <div className="text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} Real-Time Percentage Calculator. All calculations are performed locally in your browser.</p>
          <p className="mt-2">This tool is designed for educational and practical purposes.</p>
        </div>
      </div>
    </footer>
  );
}
