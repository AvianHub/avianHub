import { useState, useEffect, FormEvent } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useCopyToClipboard } from "@/hooks/use-copy-to-clipboard";
import {
  calculateStandardPercentage,
  calculateReversePercentage,
  calculatePercentageChange
} from "@/lib/calculators";

type CalculationType = "percentageOfY" | "valueOfPercentage" | "percentageChange";

export default function AdvancedCalculator() {
  const [calculationType, setCalculationType] = useState<CalculationType>("percentageOfY");
  
  // For "percentageOfY"
  const [valueX, setValueX] = useState<string>("");
  const [valueY, setValueY] = useState<string>("");
  
  // For "valueOfPercentage"
  const [percentageX, setPercentageX] = useState<string>("");
  const [totalY, setTotalY] = useState<string>("");
  
  // For "percentageChange"
  const [percentageChange, setPercentageChange] = useState<string>("");
  const [originalValue, setOriginalValue] = useState<string>("");
  
  const [result, setResult] = useState<string>("Result: 0.00%");
  const [formula, setFormula] = useState<string>("Formula: (X / Y) × 100");
  const [explanation, setExplanation] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  
  const { copyToClipboard } = useCopyToClipboard();

  useEffect(() => {
    resetInputs();
    updateFormula();
  }, [calculationType]);

  useEffect(() => {
    calculateResult();
  }, [calculationType, valueX, valueY, percentageX, totalY, percentageChange, originalValue]);

  const resetInputs = () => {
    // Reset all inputs when changing calculation type
    setValueX("");
    setValueY("");
    setPercentageX("");
    setTotalY("");
    setPercentageChange("");
    setOriginalValue("");
    setResult(calculationType === "valueOfPercentage" ? "Result: 0.00" : "Result: 0.00%");
    setExplanation("");
    setError(null);
  };

  const updateFormula = () => {
    switch (calculationType) {
      case "percentageOfY":
        setFormula("Formula: (X / Y) × 100");
        break;
      case "valueOfPercentage":
        setFormula("Formula: (X% × Y) / 100");
        break;
      case "percentageChange":
        setFormula("Formula: Original Value × (1 + X% / 100)");
        break;
    }
  };

  const calculateResult = () => {
    setError(null);

    switch (calculationType) {
      case "percentageOfY": {
        if (!valueX || !valueY) {
          setResult("Result: 0.00%");
          setExplanation("");
          return;
        }

        const x = parseFloat(valueX);
        const y = parseFloat(valueY);

        if (isNaN(x) || isNaN(y)) {
          setResult("Result: 0.00%");
          setExplanation("");
          return;
        }

        if (y === 0) {
          setError("Error: Cannot divide by zero");
          setResult("Result: Undefined");
          setExplanation("");
          return;
        }

        const percentage = calculateStandardPercentage(x, y);
        setResult(`Result: ${percentage.toFixed(2)}%`);
        setExplanation(`${x} is ${percentage.toFixed(2)}% of ${y}`);
        break;
      }
      case "valueOfPercentage": {
        if (!percentageX || !totalY) {
          setResult("Result: 0.00");
          setExplanation("");
          return;
        }

        const percentage = parseFloat(percentageX);
        const total = parseFloat(totalY);

        if (isNaN(percentage) || isNaN(total)) {
          setResult("Result: 0.00");
          setExplanation("");
          return;
        }

        const value = calculateReversePercentage(percentage, total);
        setResult(`Result: ${value.toFixed(2)}`);
        setExplanation(`${percentage}% of ${total} is ${value.toFixed(2)}`);
        break;
      }
      case "percentageChange": {
        if (!percentageChange || !originalValue) {
          setResult("Result: 0.00");
          setExplanation("");
          return;
        }

        const percentage = parseFloat(percentageChange);
        const original = parseFloat(originalValue);

        if (isNaN(percentage) || isNaN(original)) {
          setResult("Result: 0.00");
          setExplanation("");
          return;
        }

        const { newValue, change } = calculatePercentageChange(percentage, original);
        setResult(`Result: ${newValue.toFixed(2)}`);

        if (percentage >= 0) {
          setExplanation(`${original} increased by ${percentage}% is ${newValue.toFixed(2)} (a change of +${change.toFixed(2)})`);
        } else {
          setExplanation(`${original} decreased by ${Math.abs(percentage)}% is ${newValue.toFixed(2)} (a change of ${change.toFixed(2)})`);
        }
        break;
      }
    }
  };

  const handleReset = (e: FormEvent) => {
    e.preventDefault();
    resetInputs();
  };

  const handleCopy = () => {
    copyToClipboard(result);
  };

  const renderInputFields = () => {
    switch (calculationType) {
      case "percentageOfY":
        return (
          <>
            <div className="form-group">
              <Label htmlFor="advancedValueX" className="block text-sm font-medium text-gray-700 mb-1">
                Value X
              </Label>
              <Input
                type="number"
                id="advancedValueX"
                name="advancedValueX"
                placeholder="Enter value"
                className="px-4 py-3 bg-white"
                step="any"
                value={valueX}
                onChange={(e) => setValueX(e.target.value)}
              />
            </div>
            <div className="form-group">
              <Label htmlFor="advancedValueY" className="block text-sm font-medium text-gray-700 mb-1">
                Value Y (Total)
              </Label>
              <Input
                type="number"
                id="advancedValueY"
                name="advancedValueY"
                placeholder="Enter total"
                className="px-4 py-3 bg-white"
                step="any"
                value={valueY}
                onChange={(e) => setValueY(e.target.value)}
              />
            </div>
          </>
        );
      case "valueOfPercentage":
        return (
          <>
            <div className="form-group">
              <Label htmlFor="advancedPercentageX" className="block text-sm font-medium text-gray-700 mb-1">
                Percentage X
              </Label>
              <div className="relative">
                <Input
                  type="number"
                  id="advancedPercentageX"
                  name="advancedPercentageX"
                  placeholder="Enter percentage"
                  className="px-4 py-3 bg-white pr-8"
                  step="any"
                  value={percentageX}
                  onChange={(e) => setPercentageX(e.target.value)}
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <span className="text-gray-500">%</span>
                </div>
              </div>
            </div>
            <div className="form-group">
              <Label htmlFor="advancedTotalY" className="block text-sm font-medium text-gray-700 mb-1">
                Value Y (Total)
              </Label>
              <Input
                type="number"
                id="advancedTotalY"
                name="advancedTotalY"
                placeholder="Enter total"
                className="px-4 py-3 bg-white"
                step="any"
                value={totalY}
                onChange={(e) => setTotalY(e.target.value)}
              />
            </div>
          </>
        );
      case "percentageChange":
        return (
          <>
            <div className="form-group">
              <Label htmlFor="advancedPercentageChange" className="block text-sm font-medium text-gray-700 mb-1">
                Percentage Change
              </Label>
              <div className="relative">
                <Input
                  type="number"
                  id="advancedPercentageChange"
                  name="advancedPercentageChange"
                  placeholder="Enter percentage"
                  className="px-4 py-3 bg-white pr-8"
                  step="any"
                  value={percentageChange}
                  onChange={(e) => setPercentageChange(e.target.value)}
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <span className="text-gray-500">%</span>
                </div>
              </div>
            </div>
            <div className="form-group">
              <Label htmlFor="advancedOriginalValue" className="block text-sm font-medium text-gray-700 mb-1">
                Original Value
              </Label>
              <Input
                type="number"
                id="advancedOriginalValue"
                name="advancedOriginalValue"
                placeholder="Enter original value"
                className="px-4 py-3 bg-white"
                step="any"
                value={originalValue}
                onChange={(e) => setOriginalValue(e.target.value)}
              />
            </div>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <Card className="bg-white rounded-lg shadow-sm p-6 mb-6">
      <CardContent className="p-0">
        <h3 className="text-lg font-semibold mb-4">Advanced Percentage Calculator</h3>
        <p className="text-gray-600 mb-6">Select a calculation type and enter values.</p>
        
        <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
          <div className="mb-4">
            <Label className="block text-sm font-medium text-gray-700 mb-2">Calculation Type</Label>
            <RadioGroup value={calculationType} onValueChange={(value) => setCalculationType(value as CalculationType)} className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="percentageOfY" id="percentageOfY" />
                <Label htmlFor="percentageOfY" className="text-sm text-gray-700">What percentage is X of Y?</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="valueOfPercentage" id="valueOfPercentage" />
                <Label htmlFor="valueOfPercentage" className="text-sm text-gray-700">What is X% of Y?</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="percentageChange" id="percentageChange" />
                <Label htmlFor="percentageChange" className="text-sm text-gray-700">How much is X% increase/decrease?</Label>
              </div>
            </RadioGroup>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {renderInputFields()}
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-gray-700">Result</h4>
                <p className="text-sm text-gray-500">{formula}</p>
              </div>
              <div className="flex items-center">
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="icon"
                  onClick={handleCopy}
                  className="p-2 text-gray-500 hover:text-primary-600" 
                  aria-label="Copy result"
                >
                  <span className="material-icons-round">content_copy</span>
                </Button>
              </div>
            </div>
            <div className="mt-2">
              <p className="text-2xl font-bold text-primary-600">{result}</p>
              {explanation && <p className="text-sm text-gray-600 mt-1">{explanation}</p>}
              {error && <p className="text-error-600">{error}</p>}
            </div>
          </div>
          
          <div className="flex justify-end">
            <Button 
              type="button" 
              variant="outline" 
              onClick={handleReset}
              className="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200"
            >
              Reset
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
