import { Card, CardContent } from "@/components/ui/card";

export default function HowItWorks() {
  return (
    <section className="max-w-4xl mx-auto mt-12">
      <Card className="bg-white rounded-lg shadow-sm">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-4">How Percentage Calculations Work</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium mb-2">Standard Percentage</h3>
              <p className="text-gray-600 mb-3">To find what percentage one number is of another:</p>
              <div className="bg-gray-50 p-3 rounded-md mb-2">
                <p className="font-mono">(Value ÷ Total) × 100 = Percentage</p>
              </div>
              <p className="text-sm text-gray-500">Example: What percentage is 25 of 200?<br/>(25 ÷ 200) × 100 = 12.5%</p>
            </div>
            <div>
              <h3 className="font-medium mb-2">Reverse Percentage</h3>
              <p className="text-gray-600 mb-3">To find a value that is a certain percentage of a total:</p>
              <div className="bg-gray-50 p-3 rounded-md mb-2">
                <p className="font-mono">(Percentage × Total) ÷ 100 = Value</p>
              </div>
              <p className="text-sm text-gray-500">Example: What is 15% of 80?<br/>(15 × 80) ÷ 100 = 12</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
