import { useState, useEffect, FormEvent } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useCopyToClipboard } from "@/hooks/use-copy-to-clipboard";
import { calculateReversePercentage } from "@/lib/calculators";

export default function ReverseCalculator() {
  const [percentage, setPercentage] = useState<string>("");
  const [total, setTotal] = useState<string>("");
  const [result, setResult] = useState<string>("Result: 0.00");
  const [explanation, setExplanation] = useState<string>("What is 0% of 0? → 0");
  const [error, setError] = useState<string | null>(null);
  const { copyToClipboard } = useCopyToClipboard();

  useEffect(() => {
    calculateResult();
  }, [percentage, total]);

  const calculateResult = () => {
    setError(null);

    if (!percentage && !total) {
      setResult("Result: 0.00");
      setExplanation("What is 0% of 0? → 0");
      return;
    }

    const numPercentage = parseFloat(percentage);
    const numTotal = parseFloat(total);

    if (isNaN(numPercentage) || isNaN(numTotal)) {
      setResult("Result: 0.00");
      setExplanation(`What is ${isNaN(numPercentage) ? 0 : numPercentage}% of ${isNaN(numTotal) ? 0 : numTotal}? → 0`);
      return;
    }

    const value = calculateReversePercentage(numPercentage, numTotal);
    setResult(`Result: ${value.toFixed(2)}`);
    setExplanation(`What is ${numPercentage}% of ${numTotal}? → ${value.toFixed(2)}`);
  };

  const handleReset = (e: FormEvent) => {
    e.preventDefault();
    setPercentage("");
    setTotal("");
    setResult("Result: 0.00");
    setExplanation("What is 0% of 0? → 0");
    setError(null);
  };

  const handleCopy = () => {
    copyToClipboard(result);
  };

  return (
    <Card className="bg-white rounded-lg shadow-sm p-6 mb-6">
      <CardContent className="p-0">
        <h3 className="text-lg font-semibold mb-4">Reverse Percentage Calculator</h3>
        <p className="text-gray-600 mb-6">Find the value that is a certain percentage of a total.</p>
        
        <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="form-group">
              <Label htmlFor="reversePercentage" className="block text-sm font-medium text-gray-700 mb-1">
                Percentage
              </Label>
              <div className="relative">
                <Input
                  type="number"
                  id="reversePercentage"
                  name="reversePercentage"
                  placeholder="Enter percentage"
                  className="px-4 py-3 bg-white pr-8"
                  aria-describedby="reversePercentageHelp"
                  step="any"
                  value={percentage}
                  onChange={(e) => setPercentage(e.target.value)}
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <span className="text-gray-500">%</span>
                </div>
              </div>
            </div>
            
            <div className="form-group">
              <Label htmlFor="reverseTotal" className="block text-sm font-medium text-gray-700 mb-1">
                Total
              </Label>
              <Input
                type="number"
                id="reverseTotal"
                name="reverseTotal"
                placeholder="Enter total"
                className="px-4 py-3 bg-white"
                aria-describedby="reverseTotalHelp"
                step="any"
                value={total}
                onChange={(e) => setTotal(e.target.value)}
              />
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-gray-700">Result</h4>
                <p className="text-sm text-gray-500">Formula: (Percentage × Total) / 100</p>
              </div>
              <div className="flex items-center">
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="icon"
                  onClick={handleCopy}
                  className="p-2 text-gray-500 hover:text-primary-600" 
                  aria-label="Copy result"
                >
                  <span className="material-icons-round">content_copy</span>
                </Button>
              </div>
            </div>
            <div className="mt-2">
              <p className="text-2xl font-bold text-primary-600">{result}</p>
              <p className="text-sm text-gray-600 mt-1">{explanation}</p>
              {error && <p className="text-error-600">{error}</p>}
            </div>
          </div>
          
          <div className="flex justify-end">
            <Button 
              type="button" 
              variant="outline" 
              onClick={handleReset}
              className="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200"
            >
              Reset
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
