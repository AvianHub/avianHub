import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

type CalculatorTab = "standard" | "reverse" | "advanced";

interface CalculatorTabsProps {
  activeTab: CalculatorTab;
  onTabChange: (tab: CalculatorTab) => void;
}

export default function CalculatorTabs({ activeTab, onTabChange }: CalculatorTabsProps) {
  return (
    <div className="mb-6">
      <Tabs value={activeTab} onValueChange={(value) => onTabChange(value as CalculatorTab)} className="w-full">
        <TabsList className="grid grid-cols-3 gap-4 bg-transparent">
          <TabsTrigger 
            value="standard" 
            className={`inline-flex items-center justify-center p-4 ${
              activeTab === "standard" 
                ? 'bg-white text-primary-600 shadow-lg border-t-2 border-primary-500 font-medium' 
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 border border-gray-200'
            } rounded-lg transition-all duration-200`}
          >
            <span className="material-icons-round mr-2 align-middle text-xl">percent</span>
            Standard Calculator
          </TabsTrigger>
          <TabsTrigger 
            value="reverse" 
            className={`inline-flex items-center justify-center p-4 ${
              activeTab === "reverse" 
                ? 'bg-white text-primary-600 shadow-lg border-t-2 border-primary-500 font-medium' 
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 border border-gray-200'
            } rounded-lg transition-all duration-200`}
          >
            <span className="material-icons-round mr-2 align-middle text-xl">sync_alt</span>
            Reverse Calculator
          </TabsTrigger>
          <TabsTrigger 
            value="advanced" 
            className={`inline-flex items-center justify-center p-4 ${
              activeTab === "advanced" 
                ? 'bg-white text-primary-600 shadow-lg border-t-2 border-primary-500 font-medium' 
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 border border-gray-200'
            } rounded-lg transition-all duration-200`}
          >
            <span className="material-icons-round mr-2 align-middle text-xl">functions</span>
            Advanced Calculator
          </TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  );
}
