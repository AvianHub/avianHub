import { useState, useEffect, FormEvent } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useCopyToClipboard } from "@/hooks/use-copy-to-clipboard";
import { calculateStandardPercentage } from "@/lib/calculators";

export default function StandardCalculator() {
  const [value, setValue] = useState<string>("");
  const [total, setTotal] = useState<string>("");
  const [result, setResult] = useState<string>("Result: 0.00%");
  const [error, setError] = useState<string | null>(null);
  const { copyToClipboard } = useCopyToClipboard();

  useEffect(() => {
    calculateResult();
  }, [value, total]);

  const calculateResult = () => {
    setError(null);

    if (!value && !total) {
      setResult("Result: 0.00%");
      return;
    }

    const numValue = parseFloat(value);
    const numTotal = parseFloat(total);

    if (isNaN(numValue) || isNaN(numTotal)) {
      setResult("Result: 0.00%");
      return;
    }

    if (numTotal === 0) {
      setError("Error: Cannot divide by zero");
      setResult("Result: Undefined");
      return;
    }

    const result = calculateStandardPercentage(numValue, numTotal);
    setResult(`Result: ${result.toFixed(2)}%`);
  };

  const handleReset = (e: FormEvent) => {
    e.preventDefault();
    setValue("");
    setTotal("");
    setResult("Result: 0.00%");
    setError(null);
  };

  const handleCopy = () => {
    copyToClipboard(result);
  };

  return (
    <Card className="bg-white rounded-lg shadow-sm p-6 mb-6">
      <CardContent className="p-0">
        <h3 className="text-lg font-semibold mb-4">Standard Percentage Calculator</h3>
        <p className="text-gray-600 mb-6">Calculate what percentage one value is of another.</p>
        
        <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="form-group">
              <Label htmlFor="standardValue" className="block text-sm font-medium text-gray-700 mb-1">
                Value (Numerator)
              </Label>
              <Input
                type="number"
                id="standardValue"
                name="standardValue"
                placeholder="Enter value"
                className="px-4 py-3 bg-white"
                aria-describedby="standardValueHelp"
                step="any"
                value={value}
                onChange={(e) => setValue(e.target.value)}
              />
            </div>
            
            <div className="form-group">
              <Label htmlFor="standardTotal" className="block text-sm font-medium text-gray-700 mb-1">
                Total (Denominator)
              </Label>
              <Input
                type="number"
                id="standardTotal"
                name="standardTotal"
                placeholder="Enter total"
                className="px-4 py-3 bg-white"
                aria-describedby="standardTotalHelp"
                step="any"
                value={total}
                onChange={(e) => setTotal(e.target.value)}
              />
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-gray-700">Result</h4>
                <p className="text-sm text-gray-500">Formula: (Value / Total) × 100</p>
              </div>
              <div className="flex items-center">
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="icon"
                  onClick={handleCopy}
                  className="p-2 text-gray-500 hover:text-primary-600" 
                  aria-label="Copy result"
                >
                  <span className="material-icons-round">content_copy</span>
                </Button>
              </div>
            </div>
            <div className="mt-2">
              <p className="text-2xl font-bold text-primary-600">{result}</p>
              {error && <p className="text-error-600">{error}</p>}
            </div>
          </div>
          
          <div className="flex justify-end">
            <Button 
              type="button" 
              variant="outline" 
              onClick={handleReset}
              className="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200"
            >
              Reset
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
