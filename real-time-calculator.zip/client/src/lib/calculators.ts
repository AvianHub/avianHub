/**
 * Calculate standard percentage: (value / total) * 100
 */
export function calculateStandardPercentage(value: number, total: number): number {
  return (value / total) * 100;
}

/**
 * Calculate reverse percentage: (percentage * total) / 100
 */
export function calculateReversePercentage(percentage: number, total: number): number {
  return (percentage * total) / 100;
}

/**
 * Calculate percentage change: original * (1 + percentage / 100)
 * Returns both the new value and the actual change amount
 */
export function calculatePercentageChange(percentage: number, originalValue: number): { newValue: number; change: number } {
  const newValue = originalValue * (1 + percentage / 100);
  const change = newValue - originalValue;
  return { newValue, change };
}
