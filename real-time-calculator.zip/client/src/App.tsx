import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import GstCalculator from "@/pages/GstCalculator";
import ProfitLossCalculator from "@/pages/ProfitLossCalculator";
import AgeCalculator from "@/pages/AgeCalculator";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home}/>
      <Route path="/gst-calculator" component={GstCalculator}/>
      <Route path="/profit-loss-calculator" component={ProfitLossCalculator}/>
      <Route path="/age-calculator" component={AgeCalculator}/>
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
